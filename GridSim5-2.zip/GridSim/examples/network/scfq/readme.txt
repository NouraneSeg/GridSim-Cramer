
/**
 * Author: Anthony Sulistio
 * Date: March 2006
 */


When running the example file, it will produce the following files:

    *.csv -> created by NetUser.java and gridsim.net.RIPRouter.java
        to record every incoming activities.
        The format of this file is:
            simulation_time, ...

        where ... means other descriptive information.


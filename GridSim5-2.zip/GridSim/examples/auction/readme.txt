
This directory contains few GridSim auction extension examples.
Here are the summary of what each example does:
./example01 : shows how to use reverse auctions, i.e. the lowest bid 
                is the better and auctions are started by buyers.

./example02 : shows how to use different auctions, such as English, Dutch
                and First Price Seal Bid.

NOTE: Detailed explanations are provided in the source file(s).


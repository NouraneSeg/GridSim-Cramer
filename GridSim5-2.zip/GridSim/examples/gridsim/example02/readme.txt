
/**
 * Author: Anthony Sulistio
 * Date: April 2003
 */

When running this example, it will print out a list of Gridlets and their
properties. This example shows how to create Gridlets, hence nothing to simulate
yet. This example doesn't need to initialize GridSim and SimJava since creating
Gridlets are independent from running the simulation.
    

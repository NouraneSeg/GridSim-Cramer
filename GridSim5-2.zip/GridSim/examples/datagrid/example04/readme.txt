/**
 * Author: Uros Cibej and Anthony Sulistio
 * Date: March 2006
 */

This is an example of the simulation package of GridSim.datagrid.
It demonstrates how a simulation can easily be built using
a set of configuration files.

A network with 5 routers is described in network.txt
7 files are defined in files.txt
3 resources in resources.txt and
2 users in users.txt.

Each of these two users must execute a small set of tasks.
A more detailed description of this package can be found in the tutorial.
